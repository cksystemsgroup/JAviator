Java 3D(TM) 1.5.0 Release
-------------------------

This software is licensed by Sun, as specified in the LICENSE-Java3D-v1_5_0.txt file. You must only use this software in accordance with the terms under which the code is licensed.


Instructions for unzipping Java 3D 1.5.0
----------------------------------------

After downloading and unzipping the java3d-1_5_0-XXX.zip file into a temporary directory, for example, "c:\Temp", you will see the following files in the java3d-1_5_0-XXX directory:

    COPYRIGHT.txt              Copyright notice
    LICENSE-Java3D-v1_5_0.txt  Software License Agreement
    README-distribution.txt    Requirements for distribution of Java 3D files
    README-unzip.html          Instructions for manually installing the release
    README.txt                 README file (you are reading it now)
    j3d-jre.zip                Zip file containing the files to be installed

To manually install Java 3D, open README-unzip.html in your browser and follow the instructions.

